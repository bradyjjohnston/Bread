import serial
import threading

class STM32Serial:
    def __init__(self, port, baud=115200):
        self.ser = serial.Serial(port, baud, parity=serial.PARITY_EVEN, timeout=1)
        self._running = True
        self._rx_thread = threading.Thread(target=self._read_loop, daemon=True)
        self._rx_thread.start()

    def _read_loop(self):
        while self._running:
            if self.ser.in_waiting:
                data = self.ser.read(self.ser.in_waiting)
                if data:
                    print(f"[RX RAW] {data.hex()}")

    def send_packet(self, packet):
        raw = packet.to_bytes()
        self.ser.write(raw)
        print(f"[TX] {raw.hex()}")

    def close(self):
        self._running = False
        self.ser.close()

# Usage
# dev = STM32Serial("/dev/ttyACM0", 115200)
# import time; time.sleep(2)
# dev.send("ping")
# time.sleep(5)
# dev.close()